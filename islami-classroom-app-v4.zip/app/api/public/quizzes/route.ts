import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const quizzes = await prisma.quiz.findMany({
    orderBy: { createdAt: "desc" },
    take: 100,
    select: {
      id: true,
      title: true,
      description: true,
      createdAt: true,
      lesson: { select: { id: true, title: true } }
    }
  });
  return NextResponse.json({ quizzes });
}
