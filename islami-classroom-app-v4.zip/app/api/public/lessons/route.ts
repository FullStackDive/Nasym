import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET() {
  const lessons = await prisma.lesson.findMany({
    orderBy: { createdAt: "desc" },
    take: 100,
    select: { id: true, title: true, description: true, videoUrl: true, tags: true, createdAt: true }
  });
  return NextResponse.json({ lessons });
}
