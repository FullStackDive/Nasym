import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  const lesson = await prisma.lesson.findUnique({
    where: { id: params.id },
    select: { id: true, title: true, description: true, videoUrl: true, tags: true, createdAt: true }
  });
  if (!lesson) return NextResponse.json({ error: "Not found" }, { status: 404 });

  const quizzes = await prisma.quiz.findMany({
    where: { lessonId: params.id },
    orderBy: { createdAt: "desc" },
    select: { id: true, title: true, description: true, createdAt: true }
  });

  return NextResponse.json({ lesson, quizzes });
}
