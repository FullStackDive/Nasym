import { NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireActiveUser } from "@/lib/server-session";
import { userHasPermission } from "@/lib/permissions";
import { z } from "zod";

export async function GET() {
  const { session, blocked } = await requireActiveUser();
  if (!session?.user?.id) return NextResponse.json({ error: blocked ?? "Unauthorized" }, { status: 401 });

  const can = await userHasPermission(session.user.id, (session.user.role as any) ?? "STUDENT", "manage_reports" as any);
  if (!can) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const reports = await prisma.report.findMany({
    orderBy: [{ status: "asc" }, { createdAt: "desc" }],
    take: 500,
    select: {
      id: true,
      targetType: true,
      reason: true,
      details: true,
      status: true,
      createdAt: true,
      reporter: { select: { id: true, email: true, name: true } },
      lesson: { select: { id: true, title: true } },
      quiz: { select: { id: true, title: true } },
      targetUserId: true,
      resolvedAt: true
    }
  });

  return NextResponse.json({ reports });
}

const schema = z.object({
  status: z.enum(["OPEN", "RESOLVED"])
});

export async function PUT(req: Request) {
  const { session, blocked } = await requireActiveUser();
  if (!session?.user?.id) return NextResponse.json({ error: blocked ?? "Unauthorized" }, { status: 401 });

  const can = await userHasPermission(session.user.id, (session.user.role as any) ?? "STUDENT", "manage_reports" as any);
  if (!can) return NextResponse.json({ error: "Forbidden" }, { status: 403 });

  const body = await req.json().catch(() => null);
  const parsed = schema.safeParse(body);
  if (!parsed.success) return NextResponse.json({ error: "Invalid input" }, { status: 400 });

  // expects query param ?id=
  const url = new URL(req.url);
  const id = url.searchParams.get("id");
  if (!id) return NextResponse.json({ error: "Missing id" }, { status: 400 });

  const updated = await prisma.report.update({
    where: { id },
    data: {
      status: parsed.data.status as any,
      resolvedAt: parsed.data.status === "RESOLVED" ? new Date() : null,
      resolvedById: parsed.data.status === "RESOLVED" ? session.user.id : null
    },
    select: { id: true, status: true }
  });

  return NextResponse.json({ report: updated });
}
