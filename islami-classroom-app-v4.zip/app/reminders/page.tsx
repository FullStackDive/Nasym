"use client";

import { useEffect, useMemo, useState } from "react";
import { Badge, Button, Card } from "@/components/ui";

type Habit = { key: string; label: string };

const habits: Habit[] = [
  { key: "salah", label: "Pray 5 daily Salah" },
  { key: "quran", label: "Read Qur'an (10 minutes)" },
  { key: "dhikr", label: "Morning/Evening adhkar" },
  { key: "good", label: "One good deed / help someone" }
];

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${d.getMonth() + 1}-${d.getDate()}`;
}

export default function RemindersPage() {
  const storageKey = useMemo(() => `noor-habits:${todayKey()}`, []);
  const [state, setState] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const raw = localStorage.getItem(storageKey);
    setState(raw ? JSON.parse(raw) : {});
  }, [storageKey]);

  function toggle(key: string) {
    const next = { ...state, [key]: !state[key] };
    setState(next);
    localStorage.setItem(storageKey, JSON.stringify(next));
  }

  function reset() {
    setState({});
    localStorage.removeItem(storageKey);
  }

  const done = habits.filter((h) => state[h.key]).length;

  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-3xl font-black">Daily Reminders</h1>
          <p className="mt-2 text-slate-600">A simple habit checklist to stay consistent (stored on this device).</p>
        </div>
        <Badge>{done}/{habits.length} done</Badge>
      </div>

      <Card className="mt-6 p-6">
        <div className="space-y-3">
          {habits.map((h) => (
            <label key={h.key} className="flex cursor-pointer items-center justify-between rounded-2xl border border-slate-100 p-4">
              <span className="font-semibold">{h.label}</span>
              <input type="checkbox" checked={!!state[h.key]} onChange={() => toggle(h.key)} className="h-5 w-5 accent-green-600" />
            </label>
          ))}
        </div>

        <div className="mt-5 flex flex-wrap gap-2">
          <Button variant="secondary" onClick={reset}>Reset</Button>
          <a className="text-sm font-semibold text-brand-800" href="/classes">Join a class →</a>
        </div>
      </Card>
    </div>
  );
}
