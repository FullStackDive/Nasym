"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { Button, Card, Input } from "@/components/ui";

type Poster = { id: string; title: string; imageUrl: string; ctaText?: string | null; ctaHref?: string | null; createdAt: string };

export default function AdminPostersClient() {
  const [items, setItems] = useState<Poster[]>([]);
  const [title, setTitle] = useState("");
  const [imageUrl, setImageUrl] = useState("");
  const [ctaText, setCtaText] = useState("");
  const [ctaHref, setCtaHref] = useState("");
  const [err, setErr] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function refresh() {
    const res = await fetch("/api/admin/posters");
    const d = await res.json().catch(() => ({}));
    setItems(d.posters ?? []);
  }

  useEffect(() => {
    refresh();
  }, []);

  async function create(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setErr(null);
    const res = await fetch("/api/admin/posters", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title,
        imageUrl,
        ctaText: ctaText || undefined,
        ctaHref: ctaHref || undefined
      })
    });
    setSaving(false);
    if (!res.ok) {
      setErr((await res.json().catch(() => ({})))?.error ?? "Create failed");
      return;
    }
    setTitle(""); setImageUrl(""); setCtaText(""); setCtaHref("");
    await refresh();
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-3xl font-black">Poster manager</h1>
          <p className="mt-2 text-slate-600">Add attractive posters for the home page.</p>
        </div>
        <Link href="/admin"><Button variant="secondary">Back</Button></Link>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <Card className="p-6">
          <h2 className="font-extrabold">Add poster</h2>
          <form className="mt-4 space-y-3" onSubmit={create}>
            <div>
              <label className="text-sm font-semibold">Title</label>
              <Input value={title} onChange={(e) => setTitle(e.target.value)} required />
            </div>
            <div>
              <label className="text-sm font-semibold">Image URL</label>
              <Input value={imageUrl} onChange={(e) => setImageUrl(e.target.value)} type="url" required />
              <p className="mt-1 text-xs text-slate-500">Tip: use a high-res image URL.</p>
            </div>
            <div className="grid gap-3 md:grid-cols-2">
              <div>
                <label className="text-sm font-semibold">CTA Text (optional)</label>
                <Input value={ctaText} onChange={(e) => setCtaText(e.target.value)} />
              </div>
              <div>
                <label className="text-sm font-semibold">CTA Link (optional)</label>
                <Input value={ctaHref} onChange={(e) => setCtaHref(e.target.value)} placeholder="/classes" />
              </div>
            </div>
            {err && <p className="text-sm text-red-600">{err}</p>}
            <Button className="w-full" disabled={saving}>{saving ? "Saving..." : "Add"}</Button>
          </form>
        </Card>

        <Card className="p-6">
          <h2 className="font-extrabold">Existing posters</h2>
          <div className="mt-4 space-y-3">
            {items.map((p) => (
              <div key={p.id} className="rounded-2xl border border-slate-100 overflow-hidden">
                <div className="relative aspect-[16/9] w-full">
                  <Image src={p.imageUrl} alt={p.title} fill className="object-cover" sizes="(max-width:768px) 100vw, 50vw" />
                </div>
                <div className="p-4">
                  <p className="font-extrabold">{p.title}</p>
                  <p className="mt-1 text-xs text-slate-500">{new Date(p.createdAt).toLocaleString()}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
