"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useSession } from "next-auth/react";
import { Badge, Button, Card } from "@/components/ui";

type PermissionKey = "manage_users" | "manage_news" | "manage_posters" | "manage_classes" | "manage_lessons" | "manage_quizzes" | "manage_reports";

export default function DashboardClient() {
  const { data } = useSession();
  const [permissions, setPermissions] = useState<PermissionKey[]>([]);
  const [role, setRole] = useState<"ADMIN" | "STUDENT">("STUDENT");

  useEffect(() => {
    fetch("/api/me/permissions")
      .then((r) => r.json())
      .then((d) => {
        setRole(d.role ?? "STUDENT");
        setPermissions(d.permissions ?? []);
      })
      .catch(() => {});
  }, []);

  const canAdmin = role === "ADMIN" || permissions.length > 0;

  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-3xl font-black">Dashboard</h1>
          <p className="mt-2 text-slate-600">Assalamu alaikum, {data?.user?.name}.</p>
        </div>
        <Badge>{role}</Badge>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-3">
        <Card className="p-6">
          <h3 className="font-extrabold">Join classes</h3>
          <p className="mt-2 text-sm text-slate-600">View scheduled sessions and join live rooms.</p>
          <Link href="/classes" className="mt-4 inline-block">
            <Button>Open classes</Button>
          </Link>
        </Card>

        <Card className="p-6">
          <h3 className="font-extrabold">Daily reminders</h3>
          <p className="mt-2 text-sm text-slate-600">Build small habits daily.</p>
          <Link href="/reminders" className="mt-4 inline-block">
            <Button variant="secondary">Open reminders</Button>
          </Link>
        </Card>

        <Card className="p-6">
          <h3 className="font-extrabold">News board</h3>
          <p className="mt-2 text-sm text-slate-600">Read updates from admins/teachers.</p>
          <Link href="/news" className="mt-4 inline-block">
            <Button variant="secondary">Open news</Button>
          </Link>
        </Card>
      </div>

      <Card className="mt-6 p-6">
        <h2 className="text-xl font-black">Your permissions</h2>
        <p className="mt-2 text-sm text-slate-600">
          Admins have all permissions by default. Students can be given specific permissions.
        </p>

        <div className="mt-4 flex flex-wrap gap-2">
          {role === "ADMIN" ? (
            <Badge>All permissions</Badge>
          ) : permissions.length === 0 ? (
            <Badge>No special permissions</Badge>
          ) : (
            permissions.map((p) => <Badge key={p}>{p}</Badge>)
          )}
        </div>

        {canAdmin && (
          <div className="mt-6">
            <Link href="/admin"><Button>Open Admin Panel</Button></Link>
          </div>
        )}
      </Card>
    </div>
  );
}
