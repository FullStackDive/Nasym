"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Badge, Button, Card, Input, Textarea } from "@/components/ui";

type ClassSession = { id: string; title: string; description: string; scheduledAt: string; isLive: boolean; roomName: string };

export default function AdminClassesClient() {
  const [items, setItems] = useState<ClassSession[]>([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [scheduledAt, setScheduledAt] = useState("");
  const [roomName, setRoomName] = useState("");
  const [isLive, setIsLive] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function refresh() {
    const res = await fetch("/api/admin/classes");
    const d = await res.json().catch(() => ({}));
    setItems(d.sessions ?? []);
  }

  useEffect(() => {
    refresh();
  }, []);

  async function create(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setErr(null);
    const res = await fetch("/api/admin/classes", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        title,
        description,
        scheduledAt: scheduledAt ? new Date(scheduledAt).toISOString() : "",
        roomName,
        isLive
      })
    });
    setSaving(false);
    if (!res.ok) {
      setErr((await res.json().catch(() => ({})))?.error ?? "Create failed");
      return;
    }
    setTitle(""); setDescription(""); setScheduledAt(""); setRoomName(""); setIsLive(false);
    await refresh();
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-3xl font-black">Class sessions</h1>
          <p className="mt-2 text-slate-600">Create live/ scheduled classroom sessions (Jitsi rooms).</p>
        </div>
        <Link href="/admin"><Button variant="secondary">Back</Button></Link>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <Card className="p-6">
          <h2 className="font-extrabold">Create session</h2>
          <form className="mt-4 space-y-3" onSubmit={create}>
            <div>
              <label className="text-sm font-semibold">Title</label>
              <Input value={title} onChange={(e) => setTitle(e.target.value)} required />
            </div>
            <div>
              <label className="text-sm font-semibold">Description</label>
              <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={5} required />
            </div>
            <div>
              <label className="text-sm font-semibold">Scheduled at</label>
              <Input value={scheduledAt} onChange={(e) => setScheduledAt(e.target.value)} type="datetime-local" required />
              <p className="mt-1 text-xs text-slate-500">Your browser timezone will be used.</p>
            </div>
            <div>
              <label className="text-sm font-semibold">Room name</label>
              <Input value={roomName} onChange={(e) => setRoomName(e.target.value)} placeholder="noor-youth-class-01" required />
              <p className="mt-1 text-xs text-slate-500">Allowed: letters, numbers, dash, underscore.</p>
            </div>
            <label className="flex items-center justify-between rounded-2xl border border-slate-100 p-4">
              <span className="font-semibold">Mark as Live now</span>
              <input type="checkbox" checked={isLive} onChange={(e) => setIsLive(e.target.checked)} className="h-5 w-5 accent-green-600" />
            </label>
            {err && <p className="text-sm text-red-600">{err}</p>}
            <Button className="w-full" disabled={saving}>{saving ? "Saving..." : "Create"}</Button>
          </form>
        </Card>

        <Card className="p-6">
          <h2 className="font-extrabold">Existing sessions</h2>
          <div className="mt-4 space-y-3">
            {items.map((s) => (
              <div key={s.id} className="rounded-2xl border border-slate-100 p-4">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-extrabold">{s.title}</p>
                  {s.isLive ? <Badge className="bg-red-100 text-red-800">Live</Badge> : <Badge>Scheduled</Badge>}
                </div>
                <p className="mt-1 text-xs text-slate-500">{new Date(s.scheduledAt).toLocaleString()}</p>
                <p className="mt-2 text-sm text-slate-700 line-clamp-2">{s.description}</p>
                <p className="mt-2 text-xs text-slate-500">Room: {s.roomName}</p>
                <Link href={`/classes/${s.id}`} className="mt-2 inline-block text-sm font-semibold">Open classroom →</Link>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
