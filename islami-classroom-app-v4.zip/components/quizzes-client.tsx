"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Badge, Card } from "@/components/ui";

type Quiz = { id: string; title: string; description: string; createdAt: string; lesson?: { id: string; title: string } | null };

export default function QuizzesClient() {
  const [items, setItems] = useState<Quiz[]>([]);

  useEffect(() => {
    fetch("/api/public/quizzes")
      .then((r) => r.json())
      .then((d) => setItems(d.quizzes ?? []))
      .catch(() => {});
  }, []);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="text-3xl font-black">Quizzes</h1>
      <p className="mt-2 text-slate-600">Practice what you learned with short quizzes.</p>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        {items.length === 0 ? (
          <Card className="p-6 text-sm text-slate-600">No quizzes yet.</Card>
        ) : (
          items.map((q) => (
            <Card key={q.id} className="p-6">
              <div className="flex items-center justify-between gap-2">
                <h2 className="text-lg font-extrabold">{q.title}</h2>
                {q.lesson ? <Badge>{q.lesson.title}</Badge> : <Badge>Quiz</Badge>}
              </div>
              <p className="mt-3 text-sm text-slate-700 line-clamp-3">{q.description}</p>
              <div className="mt-4 flex items-center justify-between">
                <Link className="text-sm font-semibold" href={`/quizzes/${q.id}`}>Open quiz →</Link>
                <span className="text-xs text-slate-500">{new Date(q.createdAt).toLocaleDateString()}</span>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
