"use client";

import { useEffect, useMemo, useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Badge, Button, Card, cn } from "@/components/ui";

type Poster = { id: string; title: string; imageUrl: string; ctaText?: string | null; ctaHref?: string | null };
type News = { id: string; title: string; body: string; pinned: boolean; createdAt: string };
type ClassSession = { id: string; title: string; description: string; scheduledAt: string; isLive: boolean };

const ayahPool = [
  { arabic: "وَقُل رَّبِّ زِدْنِي عِلْمًا", translit: "Wa qur rabbi zidni 'ilma", ref: "Qur’an 20:114", meaning: "“My Lord, increase me in knowledge.”" },
  { arabic: "إِنَّ مَعَ الْعُسْرِ يُسْرًا", translit: "Inna ma'al 'usri yusra", ref: "Qur’an 94:6", meaning: "“With hardship comes ease.”" },
  { arabic: "وَأَقِيمُوا الصَّلَاةَ", translit: "Wa aqeemus-salah", ref: "Qur’an 2:43", meaning: "“Establish prayer.”" }
];

function formatDate(iso: string) {
  const d = new Date(iso);
  return d.toLocaleString(undefined, { weekday: "short", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
}

export default function HomeClient() {
  const [posters, setPosters] = useState<Poster[]>([]);
  const [news, setNews] = useState<News[]>([]);
  const [classes, setClasses] = useState<ClassSession[]>([]);
  const ayah = useMemo(() => ayahPool[Math.floor(Math.random() * ayahPool.length)], []);

  useEffect(() => {
    fetch("/api/public/home")
      .then((r) => r.json())
      .then((d) => {
        setPosters(d.posters ?? []);
        setNews(d.news ?? []);
        setClasses(d.upcomingClasses ?? []);
      })
      .catch(() => {});
  }, []);

  return (
    <div>
      <section className="bg-gradient-to-b from-brand-50 to-white">
        <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 md:grid-cols-2 md:items-center">
          <div>
            <Badge className="mb-3">For Youth • Clear • Kind</Badge>
            <h1 className="text-3xl font-black leading-tight tracking-tight text-slate-900 md:text-5xl">
              Learn Islam. Join live classes. Build good habits.
            </h1>
            <p className="mt-4 max-w-xl text-slate-700">
              Noor is an Islamic learning space designed for young people — live classrooms, reminders, and a positive community.
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              <Link href="/classes"><Button>Browse classes</Button></Link>
              <Link href="/lessons"><Button variant="secondary">Recorded lessons</Button></Link>
              <Link href="/quizzes"><Button variant="secondary">Quizzes</Button></Link>
              <Link href="/reminders"><Button variant="secondary">Daily reminders</Button></Link>
            </div>

            <Card className="mt-8 p-5">
              <p className="text-sm font-semibold text-brand-800">{ayah.ref}</p>
              <p className="mt-2 text-xl font-extrabold text-slate-900">{ayah.arabic}</p>
              <p className="mt-2 text-sm text-slate-600">{ayah.translit}</p>
              <p className="mt-3 text-sm text-slate-700">{ayah.meaning}</p>
            </Card>
          </div>

          <div className="relative">
            <div className="absolute -inset-2 rounded-3xl bg-brand-100 blur-2xl opacity-60" />
            <Card className="relative overflow-hidden">
              {posters.length > 0 ? (
                <div className="relative aspect-[16/10] w-full">
                  <Image
                    src={posters[0].imageUrl}
                    alt={posters[0].title}
                    fill
                    sizes="(max-width: 768px) 100vw, 50vw"
                    className="object-cover"
                    priority
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/55 to-transparent" />
                  <div className="absolute bottom-0 p-5">
                    <p className="text-white/90 text-sm font-semibold">Featured</p>
                    <h2 className="mt-1 text-white text-2xl font-black">{posters[0].title}</h2>
                    {posters[0].ctaHref && (
                      <Link href={posters[0].ctaHref} className="mt-3 inline-block">
                        <Button>{posters[0].ctaText ?? "Open"}</Button>
                      </Link>
                    )}
                  </div>
                </div>
              ) : (
                <div className="aspect-[16/10] w-full bg-brand-50 p-8">
                  <p className="text-slate-700">No posters yet. Admins can add posters from the Admin panel.</p>
                </div>
              )}
            </Card>

            <div className="mt-4 grid grid-cols-2 gap-3">
              {posters.slice(1, 5).map((p) => (
                <Card key={p.id} className="overflow-hidden">
                  <div className="relative aspect-[16/10] w-full">
                    <Image src={p.imageUrl} alt={p.title} fill className="object-cover" sizes="(max-width: 768px) 50vw, 25vw" />
                    <div className="absolute inset-0 bg-black/35" />
                    <div className="absolute bottom-0 p-3">
                      <p className="text-xs font-bold text-white line-clamp-2">{p.title}</p>
                    </div>
                  </div>
                </Card>
              ))}
              {posters.length <= 1 && (
                <Card className="col-span-2 p-4 text-sm text-slate-600">
                  Add more posters to create an attractive home slider.
                </Card>
              )}
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-6 px-4 py-10 md:grid-cols-3">
        <Card className="p-5 md:col-span-2">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-extrabold">News Board</h3>
            <Link href="/news" className="text-sm font-semibold">View all</Link>
          </div>
          <div className="mt-4 space-y-4">
            {news.length === 0 ? (
              <p className="text-sm text-slate-600">No news posts yet.</p>
            ) : (
              news.slice(0, 5).map((n) => (
                <div key={n.id} className="rounded-2xl border border-slate-100 p-4">
                  <div className="flex flex-wrap items-center gap-2">
                    {n.pinned && <Badge>Pinned</Badge>}
                    <p className="text-sm font-extrabold text-slate-900">{n.title}</p>
                    <span className="text-xs text-slate-500">{new Date(n.createdAt).toLocaleDateString()}</span>
                  </div>
                  <p className="mt-2 text-sm text-slate-700 line-clamp-3">{n.body}</p>
                </div>
              ))
            )}
          </div>
        </Card>

        <Card className="p-5">
          <h3 className="text-lg font-extrabold">Upcoming Classes</h3>
          <p className="mt-1 text-sm text-slate-600">Join live sessions (video + chat) with your teacher.</p>

          <div className="mt-4 space-y-3">
            {classes.length === 0 ? (
              <p className="text-sm text-slate-600">No scheduled classes yet.</p>
            ) : (
              classes.slice(0, 4).map((c) => (
                <div key={c.id} className="rounded-2xl border border-slate-100 p-4">
                  <div className="flex items-center justify-between">
                    <p className="font-bold">{c.title}</p>
                    {c.isLive ? <Badge className="bg-red-100 text-red-800">Live</Badge> : <Badge>Scheduled</Badge>}
                  </div>
                  <p className="mt-1 text-xs text-slate-500">{formatDate(c.scheduledAt)}</p>
                  <p className="mt-2 text-sm text-slate-700 line-clamp-2">{c.description}</p>
                  <Link href={`/classes/${c.id}`} className="mt-3 inline-block text-sm font-semibold">
                    Open classroom →
                  </Link>
                </div>
              ))
            )}
          </div>
        </Card>
      </section>

      <section className="bg-brand-50">
        <div className="mx-auto max-w-6xl px-4 py-10">
          <Card className="p-6">
            <h3 className="text-lg font-extrabold">Extra feature: Personal Habit Tracker (starter)</h3>
            <p className="mt-2 text-sm text-slate-700">
              Students can track daily goals like Salah, Qur&apos;an reading, and good deeds. This repository includes the Reminders page
              with a basic checklist (local storage). You can later connect it to the database.
            </p>
            <div className="mt-4 flex flex-wrap gap-2">
              <Link href="/reminders"><Button>Open Reminders</Button></Link>
              <Link href="/auth/register"><Button variant="secondary">Create student account</Button></Link>
            </div>
          </Card>
        </div>
      </section>
    </div>
  );
}
