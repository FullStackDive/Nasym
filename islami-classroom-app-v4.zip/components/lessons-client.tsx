"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Badge, Card } from "@/components/ui";

type Lesson = { id: string; title: string; description: string; videoUrl: string; tags?: string | null; createdAt: string };

export default function LessonsClient() {
  const [items, setItems] = useState<Lesson[]>([]);

  useEffect(() => {
    fetch("/api/public/lessons")
      .then((r) => r.json())
      .then((d) => setItems(d.lessons ?? []))
      .catch(() => {});
  }, []);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <h1 className="text-3xl font-black">Recorded Lessons</h1>
      <p className="mt-2 text-slate-600">Watch short lessons, learn step-by-step, and review anytime.</p>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        {items.length === 0 ? (
          <Card className="p-6 text-sm text-slate-600">No lessons yet.</Card>
        ) : (
          items.map((l) => (
            <Card key={l.id} className="p-6">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h2 className="text-lg font-extrabold">{l.title}</h2>
                {l.tags ? <Badge>{l.tags.split(",")[0]}</Badge> : <Badge>Lesson</Badge>}
              </div>
              <p className="mt-3 text-sm text-slate-700 line-clamp-3">{l.description}</p>
              <div className="mt-4 flex items-center justify-between">
                <Link className="text-sm font-semibold" href={`/lessons/${l.id}`}>Open lesson →</Link>
                <span className="text-xs text-slate-500">{new Date(l.createdAt).toLocaleDateString()}</span>
              </div>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
