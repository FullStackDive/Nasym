"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Badge, Button, Card, Input, Textarea } from "@/components/ui";

type News = { id: string; title: string; body: string; pinned: boolean; createdAt: string };

export default function AdminNewsClient() {
  const [posts, setPosts] = useState<News[]>([]);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [pinned, setPinned] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  async function refresh() {
    const res = await fetch("/api/admin/news");
    const d = await res.json().catch(() => ({}));
    setPosts(d.posts ?? []);
  }

  useEffect(() => {
    refresh();
  }, []);

  async function create(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    setErr(null);
    const res = await fetch("/api/admin/news", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ title, body, pinned })
    });
    setSaving(false);
    if (!res.ok) {
      setErr((await res.json().catch(() => ({})))?.error ?? "Create failed");
      return;
    }
    setTitle(""); setBody(""); setPinned(false);
    await refresh();
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-10">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-3xl font-black">News manager</h1>
          <p className="mt-2 text-slate-600">Create announcements for the home/news page.</p>
        </div>
        <Link href="/admin"><Button variant="secondary">Back</Button></Link>
      </div>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <Card className="p-6">
          <h2 className="font-extrabold">Create post</h2>
          <form className="mt-4 space-y-3" onSubmit={create}>
            <div>
              <label className="text-sm font-semibold">Title</label>
              <Input value={title} onChange={(e) => setTitle(e.target.value)} required />
            </div>
            <div>
              <label className="text-sm font-semibold">Body</label>
              <Textarea value={body} onChange={(e) => setBody(e.target.value)} rows={6} required />
            </div>
            <label className="flex items-center justify-between rounded-2xl border border-slate-100 p-4">
              <span className="font-semibold">Pinned</span>
              <input type="checkbox" checked={pinned} onChange={(e) => setPinned(e.target.checked)} className="h-5 w-5 accent-green-600" />
            </label>
            {err && <p className="text-sm text-red-600">{err}</p>}
            <Button className="w-full" disabled={saving}>{saving ? "Saving..." : "Create"}</Button>
          </form>
        </Card>

        <Card className="p-6">
          <h2 className="font-extrabold">Existing posts</h2>
          <div className="mt-4 space-y-3">
            {posts.map((n) => (
              <div key={n.id} className="rounded-2xl border border-slate-100 p-4">
                <div className="flex flex-wrap items-center gap-2">
                  {n.pinned && <Badge>Pinned</Badge>}
                  <p className="font-extrabold">{n.title}</p>
                </div>
                <p className="mt-2 text-sm text-slate-700 line-clamp-3">{n.body}</p>
                <p className="mt-2 text-xs text-slate-500">{new Date(n.createdAt).toLocaleString()}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}
